import React, { useRef, useMemo, useState, useEffect } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { OrbitControls, Html, Stars, Environment, Line, Text, Billboard, RoundedBox } from '@react-three/drei';
import * as THREE from 'three';
import { ENTITY_TYPES } from '../../data/nodes';
import { motion, AnimatePresence } from 'framer-motion';
import { MoveRight, Zap, Activity } from 'lucide-react';

const NodeLabel = React.memo(({ node, config, isHovered, onHover, onClick, isSelected, showLabels, labelStyle }) => {
  const containerRef = useRef();
  const { camera } = useThree();
  const worldPos = useMemo(() => new THREE.Vector3(node.z_x, node.z_y, node.z_z), [node.z_x, node.z_y, node.z_z]);
  const [isVisible, setIsVisible] = useState(true);
  const frameCount = useRef(0);
  const isActive = isHovered;

  useFrame(() => {
    // 1. Throttled culling check (once every 6 frames)
    if (frameCount.current % 6 === 0) {
      const dist = camera.position.distanceTo(worldPos);
      const visible = dist < 22000;
      if (visible !== isVisible) setIsVisible(visible);
    }
    
    // 2. Continuous scale logic for THE RICH ACTIVE PANEL ONLY
    if (isActive && containerRef.current) {
      const dist = camera.position.distanceTo(worldPos);
      const scale = Math.max(0.4, Math.min(1.0, 15000 / dist));
      containerRef.current.style.transform = `translate(-50%, -50%) scale(${scale})`;
      containerRef.current.style.opacity = '1';
      containerRef.current.style.pointerEvents = 'auto';
    }
    
    frameCount.current++;
  });

  const hoverTimeout = useRef();
  const handlePointerOver = (e) => {
    e.stopPropagation();
    hoverTimeout.current = setTimeout(() => onHover(node.id), 120);
  };
  const handlePointerOut = (e) => {
    e.stopPropagation();
    clearTimeout(hoverTimeout.current);
    onHover(null);
  };

  return (
    <group 
      onPointerOver={(e) => { e.stopPropagation(); onHover(node.id); }}
      onPointerOut={handlePointerOut} 
      onClick={(e) => { e.stopPropagation(); onClick(node); }}
    >
      {/* 1. NATIVE WEBGL PILL: GPU-Accelerated SDF shader (Absolute Performance) */}
      {!isActive && showLabels && labelStyle === 'pill' && isVisible && (
        <Billboard>
          {(() => {
             const pillWidth = node.title.length * 28 + 120;
             const pillHeight = 100;
             return (
               <mesh position={[0, 0, -1]}>
                 <planeGeometry args={[pillWidth, pillHeight]} />
                 <shaderMaterial
                   transparent
                   uniforms={{
                     color: { value: new THREE.Color(config.color) },
                     bgColor: { value: new THREE.Color("#050510") },
                     opacity: { value: 1.0 },
                     aspect: { value: pillWidth / pillHeight }
                   }}
                   vertexShader={`
                     varying vec2 vUv;
                     void main() {
                       vUv = uv;
                       gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
                     }
                   `}
                   fragmentShader={`
                     varying vec2 vUv;
                     uniform vec3 color;
                     uniform vec3 bgColor;
                     uniform float opacity;
                     uniform float aspect;

                     float sdRoundedBox(vec2 p, vec2 b, float r) {
                         vec2 q = abs(p) - b + r;
                         return length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - r;
                     }

                     void main() {
                         vec2 p = (vUv * 2.0 - 1.0) * vec2(aspect, 1.0);
                         float radius = 0.9;
                         float d = sdRoundedBox(p, vec2(aspect, 1.0), radius);
                         
                         if (d > 0.0) discard;
                         
                         float borderThickness = 0.12;
                         float borderMask = smoothstep(-borderThickness, -borderThickness + 0.02, d);
                         vec3 finalColor = mix(bgColor, color, borderMask);
                         
                         gl_FragColor = vec4(finalColor, opacity);
                     }
                   `}
                 />
               </mesh>
             );
          })()}
          <Text
             position={[0, 0, 1]} 
             fontSize={42}
             color="#ffffff"
             anchorX="center" anchorY="middle"
             fillOpacity={1.0}
             fontWeight={800}
             font="https://cdn.jsdelivr.net/gh/google/fonts@main/ofl/dmserifdisplay/DMSerifDisplay-Regular.ttf"
           >
             {node.title}
          </Text>
        </Billboard>
      )}

      {/* 2. STRATEGIC TEXT: Native WebGL text (Clean Corporate Look) */}
      {!isActive && showLabels && labelStyle === 'standard' && isVisible && (
        <Billboard>
            <Text
              position={[0, 0, 0]} 
              fontSize={42}
              color={config.color}
              anchorX="center" anchorY="middle"
              fillOpacity={1.0}
              fontWeight={800}
              font="https://cdn.jsdelivr.net/gh/google/fonts@main/ofl/dmserifdisplay/DMSerifDisplay-Regular.ttf"
              outlineWidth={0}
            >
              {node.title}
            </Text>
        </Billboard>
      )}

      {/* 2. RICH DOM: Only mounts when actively hovered — prevents Html anchor dot appearing at world origin */}
      {isActive && (
        <Html zIndexRange={[100, 1]}>
           <AnimatePresence>
              <motion.div 
                initial={{ opacity: 0 }} 
                animate={{ opacity: 1 }} 
                exit={{ opacity: 0 }} 
                transition={{ duration: 0.15 }}
                ref={containerRef}
                className={`w-80 cursor-pointer ${isSelected ? 'scale-110' : 'scale-105'}`}
              >
                 <div className={`overflow-hidden border-t-2 rounded-2xl bg-[#050510]/95 shadow-[0_0_50px_#00f2ff30]`}
                      style={{ borderTopColor: config.color, borderWidth: isSelected ? '3px' : '1px' }}>
                    <div className="p-5">
                      <div className="flex items-center gap-3 mb-2">
                         <config.icon size={12} style={{ color: config.color }} />
                         <span className="text-[10px] font-black uppercase tracking-[0.3em] text-slate-500">{config.label}</span>
                      </div>
                      <h3 className="text-[18px] font-bold text-white leading-tight tracking-tight">{node.title}</h3>
                    </div>
                 </div>
              </motion.div>
           </AnimatePresence>
        </Html>
      )}
      

    </group>
  );
});

const NeuralLine = React.memo(({ start, end, color, isHovered, isSecondary = false, hoveredLinkData, setHoveredLinkData }) => {
  const lineRef = useRef();
  const [lineHovered, setLineHovered] = useState(false);

  useFrame((state, delta) => {
    if (lineRef.current?.material) {
       lineRef.current.material.dashOffset -= delta * (isHovered ? 2.0 : 0.5);
    }
  });

  const points = useMemo(() => {
    const vStart = new THREE.Vector3(start.z_x || 0, start.z_y || 0, start.z_z || 0);
    const vEnd = new THREE.Vector3(end.z_x || 0, end.z_y || 0, end.z_z || 0);
    
    if (vStart.distanceTo(vEnd) < 1) return [vStart, vEnd];

    const mid = new THREE.Vector3().lerpVectors(vStart, vEnd, 0.5);
    
    if (isSecondary) {
      if (mid.length() > 0.1) {
         mid.normalize().multiplyScalar(Math.max(vStart.length(), vEnd.length(), 500) * 1.4);
      } else {
         mid.set(0, 0, 1).multiplyScalar(Math.max(vStart.length(), vEnd.length(), 1000) * 1.4);
      }
    } else {
      if (mid.length() > 0.1) {
         const naturalLength = mid.length();
         mid.normalize().multiplyScalar(naturalLength * 1.05);
      }
    }
    
    const curve = new THREE.QuadraticBezierCurve3(vStart, mid, vEnd);
    return curve.getPoints(16);
  }, [start, end, isSecondary]);

  const midPoint = points[Math.floor(points.length / 2)];
  const [hoverPoint, setHoverPoint] = useState(midPoint);

  const hoverTimeout = useRef();
  const leaveTimeout = useRef();

  const handlePointerOver = (e) => {
    e.stopPropagation();
    if (leaveTimeout.current) clearTimeout(leaveTimeout.current);
    setHoverPoint(e.point);
    hoverTimeout.current = setTimeout(() => {
      setLineHovered(true);
      if (setHoveredLinkData) {
        setHoveredLinkData({
          from: start.title,
          fromType: start.type,
          to: end.title,
          toType: end.type,
          type: isSecondary ? 'Transverse Thread' : 'Structural Pipeline'
        });
      }
    }, 120);
  };

  const handlePointerMove = (e) => {
    e.stopPropagation();
    setHoverPoint(e.point);
  };

  const handlePointerOut = (e) => {
    e.stopPropagation();
    clearTimeout(hoverTimeout.current);
    // Add a small delay to prevent flickering when cursor briefly skips across the line geometry
    leaveTimeout.current = setTimeout(() => {
      setLineHovered(false);
      if (setHoveredLinkData) setHoveredLinkData(null);
    }, 150);
  };

  return (
    <group>
      {/* Visual Rendered Line */}
      <Line
        ref={lineRef}
        points={points}
        color={color}
        lineWidth={isHovered ? 3 : (isSecondary ? 0.8 : 2.0)}
        transparent
        opacity={isHovered ? 1 : (isSecondary ? 0.15 : 0.4)}
        dashed={true}
        dashScale={isHovered ? 50 : 100}
        dashSize={isHovered ? 50 : 20}
        dashOffset={0}
      />
      {/* Invisible Hitbox Line for dramatically easier raycasting */}
      <Line
        points={points}
        lineWidth={60}
        transparent
        opacity={0}
        colorWrite={false}
        depthWrite={false}
        onPointerOver={handlePointerOver}
        onPointerMove={handlePointerMove}
        onPointerOut={handlePointerOut}
      />
      
      <Html 
        position={[hoverPoint.x, hoverPoint.y + 10, hoverPoint.z]} 
        center 
        zIndexRange={[110, 2]}
      >
         <AnimatePresence>
            {lineHovered && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.95, y: 10 }} 
                animate={{ opacity: 1, scale: 1, y: 0 }} 
                exit={{ opacity: 0, scale: 0.95, y: 10 }} 
                transition={{ duration: 0.2 }}
                className="backdrop-blur-3xl border border-white/10 p-5 rounded-3xl w-[380px] border-t-4 bg-black/90 shadow-3xl flex flex-col border-t-brand-cyan pointer-events-none"
              >
                <div className="flex items-center gap-2 mb-4">
                  <Activity size={10} className="text-brand-cyan" />
                  <span className="text-[9px] font-bold tracking-[0.15em] text-brand-cyan uppercase">Connection Details</span>
                </div>
                
                <div className="flex flex-col gap-1">
                  {/* Start Node */}
                  <div className="px-3.5 py-2.5 rounded-xl border border-white/5 bg-white/[0.02] flex items-center justify-between" style={{ borderLeft: `3px solid ${color}` }}>
                     <div className="flex flex-col">
                        <span className="text-[7px] font-black uppercase tracking-tighter text-slate-500 mb-0.5">{start.type}</span>
                        <span className="text-[12px] font-bold text-white/90 italic truncate max-w-[220px]">{start.title}</span>
                     </div>
                     <div className="text-[7px] font-black px-1.5 py-0.5 rounded-md italic uppercase tracking-widest leading-none border border-brand-cyan/20 text-brand-cyan">Start</div>
                  </div>

                  {/* Flow Arrow */}
                  <div className="py-0.5 flex justify-center opacity-40">
                     <div className="w-px h-3 bg-gradient-to-b from-brand-cyan to-transparent relative">
                        <div className="absolute -bottom-1 -left-[4.5px] border-l-[5px] border-l-transparent border-r-[5px] border-r-transparent border-t-[5px] border-t-brand-cyan" />
                     </div>
                  </div>

                  {/* End Node */}
                  <div className="px-3.5 py-2.5 rounded-xl border border-white/5 bg-white/[0.02] flex items-center justify-between" style={{ borderLeft: `3px solid ${color}` }}>
                     <div className="flex flex-col">
                        <span className="text-[7px] font-black uppercase tracking-tighter text-slate-500 mb-0.5">{end.type}</span>
                        <span className="text-[12px] font-bold text-white/90 italic truncate max-w-[220px]">{end.title}</span>
                     </div>
                     <div className="text-[7px] font-black px-1.5 py-0.5 rounded-md italic uppercase tracking-widest leading-none border border-slate-700 text-slate-400">End</div>
                  </div>

                  <div className="mt-3 pt-3 border-t border-white/5 flex justify-center">
                    <span className="text-[9px] font-bold text-brand-cyan/80 bg-brand-cyan/5 px-3 py-1.5 rounded-full italic tracking-[0.05em] uppercase">{isSecondary ? 'Transverse Thread' : 'Structural Pipeline'}</span>
                  </div>
                </div>
              </motion.div>
            )}
         </AnimatePresence>
      </Html>
    </group>
  );
});

const NeuralMesh = ({ nodes, onSelectNode, hoveredNodeId, setHoveredNodeId, selectedNode, spatialNodes, showLabels, labelStyle, hoveredLinkData, setHoveredLinkData }) => {
  const meshGroup = useRef();
  
  useFrame((state, delta) => {
    // Only rotate if no investigative interaction is happening
    const isInteracting = selectedNode || hoveredNodeId || hoveredLinkData;
    
    if (meshGroup.current && !isInteracting) {
      meshGroup.current.rotation.y += delta * 0.05; 
      meshGroup.current.rotation.z += delta * 0.01;
    }
  });

  const links = useMemo(() => {
    const l = [];
    const seen = new Set();
    spatialNodes.forEach(node => {
      if (node.parentId) {
        const p = spatialNodes.find(n => n.id === node.parentId);
        if (p) {
          const lKey = `h-${p.id}-${node.id}`;
          if (!seen.has(lKey)) {
            l.push({ key: lKey, from: p, to: node, type: 'parent', color: ENTITY_TYPES[node.type?.toUpperCase()]?.color || '#00f2ff' });
            seen.add(lKey);
          }
        }
      }
      (node.secondaryLinks || []).forEach(sid => {
        const target = spatialNodes.find(n => n.id === sid);
        if (target) {
          const lKey = `s-${node.id}-${target.id}`;
          if (!seen.has(lKey)) {
            l.push({ key: lKey, from: node, to: target, type: 'secondary', color: '#ff00d4' });
            seen.add(lKey);
          }
        }
      });
    });
    return l;
  }, [spatialNodes]);

  return (
    <group ref={meshGroup}>
      <group>
        {links.map((link) => (
          <NeuralLine 
            key={link.key} 
            start={link.from} 
            end={link.to} 
            color={link.color} 
            isHovered={hoveredNodeId === link.from.id || hoveredNodeId === link.to.id}
            isSecondary={link.type === 'secondary'}
            hoveredLinkData={hoveredLinkData}
            setHoveredLinkData={setHoveredLinkData}
          />
        ))}

        {spatialNodes.map(node => {
          const config = ENTITY_TYPES[node.type?.toUpperCase()] || ENTITY_TYPES.CONCEPT;
          const isSelected = selectedNode?.id === node.id;
          const isHovered = hoveredNodeId === node.id;
          
          return (
            <group key={`node-${node.id}`} position={[node.z_x, node.z_y, node.z_z]}>
                <NodeLabel 
                  node={node} config={config} isHovered={isHovered} 
                  onHover={setHoveredNodeId} onClick={onSelectNode} isSelected={isSelected}
                  showLabels={showLabels}
                  labelStyle={labelStyle}
                />
            </group>
          );
        })}
      </group>
    </group>
  );
};

const CameraController = ({ targetNode }) => {
  const { camera, controls } = useThree();
  const [isCanceled, setIsCanceled] = useState(false);
  
  useEffect(() => { setIsCanceled(false); }, [targetNode]);

  useEffect(() => {
    if (!targetNode || !controls || isCanceled) return;
    
    const targetPos = new THREE.Vector3(targetNode.z_x, targetNode.z_y, targetNode.z_z);
    
    const approachRadius = targetNode.depth === 0 ? 5000 : 2500;
    const cameraOffset = targetPos.clone().normalize().multiplyScalar(approachRadius); 
    if (cameraOffset.length() === 0) cameraOffset.set(0, 0, approachRadius);
    
    const idealPos = targetPos.clone().add(cameraOffset);
    
    const onIntervene = () => setIsCanceled(true);
    controls.addEventListener('start', onIntervene);

    let frameId;
    const animate = () => {
       if (isCanceled) return;
       camera.position.lerp(idealPos, 0.05);
       controls.target.lerp(targetPos, 0.08);
       controls.update();
       if (camera.position.distanceTo(idealPos) > 10) frameId = requestAnimationFrame(animate);
    };
    animate();

    return () => {
       cancelAnimationFrame(frameId);
       controls.removeEventListener('start', onIntervene);
    };
  }, [targetNode, camera, controls, isCanceled]);

  return null;
};

export const SpatialCanvas = ({ nodes, onSelectNode, hoveredNodeId, setHoveredNodeId, selectedNode, showLabels, labelStyle, hoveredLinkData, setHoveredLinkData }) => {
  const spatialNodes = useMemo(() => {
    const processed = [];
    const seen = new Set();

    const walk = (nid, depth = 0, thetaRange = [0, Math.PI * 2], phiRange = [0.2, Math.PI - 0.2]) => {
      if (seen.has(nid)) return;
      const node = nodes.find(n => n.id === nid);
      if (!node) return;
      seen.add(nid);

      // BALANCED RADIAL SHELLS
      const radius = depth === 0 ? 0 : 2000 + (depth - 1) * 1800;
      
      // Calculate geometric center of this node's assigned heavenly real estate
      const theta = (thetaRange[0] + thetaRange[1]) / 2;
      const phi = (phiRange[0] + phiRange[1]) / 2;
      
      const z_x = radius * Math.sin(phi) * Math.cos(theta);
      const z_y = radius * Math.sin(phi) * Math.sin(theta);
      const z_z = radius * Math.cos(phi);

      processed.push({ ...node, z_x, z_y, z_z, depth });

      const children = nodes.filter(n => n.parentId === nid);
      if (children.length > 0) {
        // Constriction factor to create 'breathing room' between disparate constellations
        const tSpan = (thetaRange[1] - thetaRange[0]) * 0.85;
        const pSpan = (phiRange[1] - phiRange[0]) * 0.85;
        
        const startT = theta - tSpan / 2;
        const startP = phi - pSpan / 2;

        const N = children.length;
        
        // DYNAMIC SPHERICAL PATCH GRIDDING
        // We split the available surface area into horizontal and vertical slices
        const cols = Math.ceil(Math.sqrt(N));
        const rows = Math.ceil(N / cols);
        
        const pStep = pSpan / rows;

        children.forEach((child, i) => {
          const row = Math.floor(i / cols);
          const col = i % cols;
          
          // Auto-center incomplete final rows
          const itemsInThisRow = (row === rows - 1 && N % cols !== 0) ? N % cols : cols;
          const dynamicTStep = tSpan / itemsInThisRow;
          
          const c_tStart = startT + col * dynamicTStep;
          const c_tEnd = startT + (col + 1) * dynamicTStep;

          const c_pStart = startP + row * pStep;
          const c_pEnd = startP + (row + 1) * pStep;

          walk(child.id, depth + 1, [c_tStart, c_tEnd], [c_pStart, c_pEnd]);
        });
      }
    };

    const roots = nodes.filter(n => !n.parentId);
    roots.forEach((root, i) => {
      const step = (Math.PI * 2) / roots.length;
      walk(root.id, 0, [i * step, (i + 1) * step], [0.4, Math.PI - 0.4]);
    });

    nodes.forEach(n => {
      if (!seen.has(n.id)) {
        processed.push({ ...n, z_x: (Math.random() - 0.5) * 5000, z_y: (Math.random() - 0.5) * 5000, z_z: -1000, depth: 0 });
      }
    });

    return processed;
  }, [nodes]);

  const activeSpatialNode = useMemo(() => 
    selectedNode ? spatialNodes.find(n => n.id === selectedNode.id) : null
  , [selectedNode, spatialNodes]);

  return (
    <div className="w-full h-full bg-black relative">
      <Canvas shadows camera={{ position: [0, 0, 8500], fov: 32, near: 10, far: 500000 }} dpr={[1, 2]}>
        <color attach="background" args={['#000000']} />
        
        <ambientLight intensity={2.5} />
        <directionalLight position={[10000, 10000, 10000]} intensity={3.0} color="#00f2ff" />
        <directionalLight position={[-10000, -10000, 5000]} intensity={1.5} color="#ffffff" />
        
        <OrbitControls 
          makeDefault enableDamping dampingFactor={0.05} rotateSpeed={0.5}
          maxDistance={150000} minDistance={100}
        />
        
        <CameraController targetNode={activeSpatialNode} />
        <NeuralMesh 
          nodes={nodes} 
          onSelectNode={onSelectNode} 
          hoveredNodeId={hoveredNodeId} 
          setHoveredNodeId={setHoveredNodeId} 
          selectedNode={selectedNode} 
          spatialNodes={spatialNodes}
          showLabels={showLabels}
          labelStyle={labelStyle}
          hoveredLinkData={hoveredLinkData}
          setHoveredLinkData={setHoveredLinkData}
        />
        
        <Environment preset="night" />
      </Canvas>
    </div>
  );
};

import React, { useRef, useMemo, useState, useEffect } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { OrbitControls, Html, Stars, Environment, Sphere, Line } from '@react-three/drei';
import * as THREE from 'three';
import { ENTITY_TYPES } from '../../data/nodes';

const NodeLabel = ({ node, config, isHovered, onHover, onClick, isSelected }) => {
  const containerRef = useRef();
  const { camera } = useThree();
  
  // PRE-ALLOCATE VECTOR: Prevent 4,200 GC allocations per second
  const worldPos = useMemo(() => new THREE.Vector3(node.z_x, node.z_y, node.z_z), [node.z_x, node.z_y, node.z_z]);

  useFrame(() => {
    if (!containerRef.current) return;
    const dist = camera.position.distanceTo(worldPos);
    
    const opacity = Math.max(0, Math.min(1, 2.0 - dist / 15000));
    
    // THROTTLE DOM PAINTS
    if (opacity < 0.05) {
       if (containerRef.current.style.display !== 'none') containerRef.current.style.display = 'none';
       return;
    }
    if (containerRef.current.style.display !== 'block') containerRef.current.style.display = 'block';

    const scale = Math.max(0.4, Math.min(1.2, 5000 / dist));
    
    containerRef.current.style.opacity = opacity;
    containerRef.current.style.transform = `translate(-50%, -50%) scale(${scale})`;
    containerRef.current.style.pointerEvents = opacity < 0.2 ? 'none' : 'auto';
  });

  return (
    <Html 
      zIndexRange={[100, 1]}
      style={{ transition: 'opacity 0.2s' }}
    >
      <div 
        ref={containerRef}
        onMouseEnter={() => onHover(node.id)}
        onMouseLeave={() => onHover(null)}
        onClick={(e) => { e.stopPropagation(); onClick(node); }}
        className={`w-80 cursor-pointer transition-all duration-300 ${isSelected ? 'scale-110' : 'hover:scale-105'}`}
      >
         {/* PERFORMANCE PURGE: Removed backdrop-filter to prevent 60FPS browser compositor stalls */}
         <div className={`overflow-hidden border-t-2 rounded-2xl transition-all duration-500 ${isHovered ? 'bg-[#050510]/95 shadow-[0_0_40px_#00f2ff30]' : 'bg-[#050510]/80'}`}
              style={{ 
                  borderTopColor: config.color,
                  borderWidth: isSelected ? '3px' : '1px'
              }}>
            <div className="p-5">
              <div className="flex items-center gap-3 mb-2">
                 <config.icon size={12} style={{ color: config.color }} />
                 <span className="text-[10px] font-black uppercase tracking-[0.3em] text-slate-500">{config.label}</span>
              </div>
              <h3 className="text-[16px] font-bold text-white leading-tight italic tracking-tight">{node.title}</h3>
            </div>
         </div>
      </div>
    </Html>
  );
};

const NeuralLine = ({ start, end, color, isHovered, isSecondary = false }) => {
  const points = useMemo(() => {
    const vStart = new THREE.Vector3(start.z_x || 0, start.z_y || 0, start.z_z || 0);
    const vEnd = new THREE.Vector3(end.z_x || 0, end.z_y || 0, end.z_z || 0);
    
    if (vStart.distanceTo(vEnd) < 1) return [vStart, vEnd];

    const mid = new THREE.Vector3().lerpVectors(vStart, vEnd, 0.5);
    const archFactor = isSecondary ? 1.4 : 1.25;
    
    if (mid.length() > 0.1) {
       mid.normalize().multiplyScalar(Math.max(vStart.length(), vEnd.length(), 500) * archFactor);
    } else {
       mid.set(0, 0, 1).multiplyScalar(Math.max(vStart.length(), vEnd.length(), 1000) * archFactor);
    }
    
    const curve = new THREE.QuadraticBezierCurve3(vStart, mid, vEnd);
    // OPTIMIZATION: Reduced spline fidelity by 50%
    return curve.getPoints(16);
  }, [start, end, isSecondary]);

  return (
    <Line
      points={points}
      color={color}
      lineWidth={isHovered ? 6 : (isSecondary ? 0.8 : 2.0)}
      transparent
      opacity={isHovered ? 1 : (isSecondary ? 0.15 : 0.4)}
    />
  );
};

const NeuralMesh = ({ nodes, onSelectNode, hoveredNodeId, setHoveredNodeId, selectedNode, spatialNodes }) => {
  const meshGroup = useRef();
  
  useFrame((state, delta) => {
    if (meshGroup.current && !selectedNode) {
      meshGroup.current.rotation.y += delta * 0.05; 
      meshGroup.current.rotation.z += delta * 0.01;
    }
  });

  const links = useMemo(() => {
    const l = [];
    const seen = new Set();
    spatialNodes.forEach(node => {
      if (node.parentId) {
        const p = spatialNodes.find(n => n.id === node.parentId);
        if (p) {
          const lKey = `h-${p.id}-${node.id}`;
          if (!seen.has(lKey)) {
            l.push({ key: lKey, from: p, to: node, type: 'parent', color: ENTITY_TYPES[node.type?.toUpperCase()]?.color || '#00f2ff' });
            seen.add(lKey);
          }
        }
      }
      (node.secondaryLinks || []).forEach(sid => {
        const target = spatialNodes.find(n => n.id === sid);
        if (target) {
          const lKey = `s-${node.id}-${target.id}`;
          if (!seen.has(lKey)) {
            l.push({ key: lKey, from: node, to: target, type: 'secondary', color: '#ff00d4' });
            seen.add(lKey);
          }
        }
      });
    });
    return l;
  }, [spatialNodes]);

  return (
    <group ref={meshGroup}>
      {/* OPTIMIZATION: Dropped star count severely */}
      <Stars radius={10000} depth={1000} count={3000} factor={4} saturation={0} fade speed={1} />
      
      <group>
        {links.map((link) => (
          <NeuralLine 
            key={link.key} 
            start={link.from} end={link.to} color={link.color}
            isHovered={hoveredNodeId === link.from.id || hoveredNodeId === link.to.id}
            isSecondary={link.type === 'secondary'}
          />
        ))}

        {spatialNodes.map(node => {
          const config = ENTITY_TYPES[node.type?.toUpperCase()] || ENTITY_TYPES.CONCEPT;
          const isSelected = selectedNode?.id === node.id;
          const isHovered = hoveredNodeId === node.id;
          
          return (
            <group key={`node-${node.id}`} position={[node.z_x, node.z_y, node.z_z]}>
              <NodeLabel 
                node={node} config={config} isHovered={isHovered} 
                onHover={setHoveredNodeId} onClick={onSelectNode} isSelected={isSelected}
              />
              <mesh>
                {/* OPTIMIZATION: Reduced polygon array footprint */}
                <sphereGeometry args={[isSelected ? 100 : 50, 16, 16]} />
                <meshStandardMaterial 
                  color={config.color} 
                  emissive={config.color} 
                  emissiveIntensity={isHovered ? 12 : 3}
                  transparent 
                  opacity={1}
                />
              </mesh>
              {(isHovered || isSelected) && (
                <mesh>
                  <sphereGeometry args={[isSelected ? 140 : 90, 16, 16]} />
                  <meshBasicMaterial color={config.color} transparent opacity={0.15} wireframe />
                </mesh>
              )}
            </group>
          );
        })}
      </group>
    </group>
  );
};

const CameraController = ({ targetNode }) => {
  const { camera, controls } = useThree();
  const [isCanceled, setIsCanceled] = useState(false);
  
  useEffect(() => { setIsCanceled(false); }, [targetNode]);

  useEffect(() => {
    if (!targetNode || !controls || isCanceled) return;
    
    const targetPos = new THREE.Vector3(targetNode.z_x, targetNode.z_y, targetNode.z_z);
    
    const approachRadius = targetNode.depth === 0 ? 5000 : 2500;
    const cameraOffset = targetPos.clone().normalize().multiplyScalar(approachRadius); 
    if (cameraOffset.length() === 0) cameraOffset.set(0, 0, approachRadius);
    
    const idealPos = targetPos.clone().add(cameraOffset);
    
    const onIntervene = () => setIsCanceled(true);
    controls.addEventListener('start', onIntervene);

    let frameId;
    const animate = () => {
       if (isCanceled) return;
       camera.position.lerp(idealPos, 0.05);
       controls.target.lerp(targetPos, 0.08);
       controls.update();
       if (camera.position.distanceTo(idealPos) > 10) frameId = requestAnimationFrame(animate);
    };
    animate();

    return () => {
       cancelAnimationFrame(frameId);
       controls.removeEventListener('start', onIntervene);
    };
  }, [targetNode, camera, controls, isCanceled]);

  return null;
};

export const SpatialCanvas = ({ nodes, onSelectNode, hoveredNodeId, setHoveredNodeId, selectedNode }) => {
  const spatialNodes = useMemo(() => {
    const processed = [];
    const seen = new Set();

    const walk = (nid, depth = 0, thetaRange = [0, Math.PI * 2], phiRange = [0.4, Math.PI - 0.4]) => {
      if (seen.has(nid)) return;
      const node = nodes.find(n => n.id === nid);
      if (!node) return;
      seen.add(nid);

      // BALANCED RADIAL SHELLS
      const radius = depth === 0 ? 0 : 2000 + (depth - 1) * 1800;
      const theta = (thetaRange[0] + thetaRange[1]) / 2;
      const phi = (phiRange[0] + phiRange[1]) / 2;
      
      const z_x = radius * Math.sin(phi) * Math.cos(theta);
      const z_y = radius * Math.sin(phi) * Math.sin(theta);
      const z_z = radius * Math.cos(phi);

      processed.push({ ...node, z_x, z_y, z_z, depth });

      const children = nodes.filter(n => n.parentId === nid);
      if (children.length > 0) {
        const tSpan = (thetaRange[1] - thetaRange[0]) * 0.9;
        const pSpan = (phiRange[1] - phiRange[0]) * 0.9;
        
        const startT = theta - tSpan/2;
        const startP = phi - pSpan/2;

        children.forEach((child, i) => {
          const tStart = startT + (i / children.length) * tSpan;
          const tEnd = startT + ((i + 1) / children.length) * tSpan;
          walk(child.id, depth + 1, [tStart, tEnd], [startP, startP + pSpan]);
        });
      }
    };

    const roots = nodes.filter(n => !n.parentId);
    roots.forEach((root, i) => {
      const step = (Math.PI * 2) / roots.length;
      walk(root.id, 0, [i * step, (i + 1) * step], [0.4, Math.PI - 0.4]);
    });

    nodes.forEach(n => {
      if (!seen.has(n.id)) {
        processed.push({ ...n, z_x: (Math.random() - 0.5) * 5000, z_y: (Math.random() - 0.5) * 5000, z_z: -1000, depth: 0 });
      }
    });

    return processed;
  }, [nodes]);

  const activeSpatialNode = useMemo(() => 
    selectedNode ? spatialNodes.find(n => n.id === selectedNode.id) : null
  , [selectedNode, spatialNodes]);

  return (
    <div className="w-full h-full bg-black relative">
      <Canvas shadows camera={{ position: [0, 0, 8500], fov: 32, near: 10, far: 500000 }} dpr={[1, 2]}>
        <color attach="background" args={['#000000']} />
        
        <ambientLight intensity={2.5} />
        <directionalLight position={[10000, 10000, 10000]} intensity={3.0} color="#00f2ff" />
        <pointLight position={[0, 0, 0]} intensity={4.0} color="#ffffff" />
        
        <OrbitControls 
          makeDefault enableDamping dampingFactor={0.05} rotateSpeed={0.5}
          maxDistance={150000} minDistance={100}
        />
        
        <CameraController targetNode={activeSpatialNode} />
        <NeuralMesh 
          nodes={nodes} onSelectNode={onSelectNode} hoveredNodeId={hoveredNodeId} 
          setHoveredNodeId={setHoveredNodeId} selectedNode={selectedNode} spatialNodes={spatialNodes}
        />
        
        <Environment preset="night" />
      </Canvas>
      
      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 pointer-events-none">
         <div className="px-6 py-3 bg-brand-cyan/5 border border-brand-cyan/40 backdrop-blur-3xl rounded-full flex items-center gap-4 shadow-3xl">
            <div className="w-2 h-2 rounded-full bg-brand-cyan animate-pulse shadow-[0_0_20px_#00f0ff]" />
            <span className="text-[11px] font-black uppercase tracking-[0.4em] text-brand-cyan/80">Neural_Orbital_Shell_Active</span>
         </div>
      </div>
    </div>
  );
};
